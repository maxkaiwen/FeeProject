package com.example.demo.dao;

public interface StudentLinkDAO {
	public void linkStudent(int perm, int perm_lv);
	public void deLinkStudent(int perm, int perm_lv);
}
